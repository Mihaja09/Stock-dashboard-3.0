                <div class="col"></div>
                <div class="centerform">    
                    
                    <div class="formul">
                        <div class="entete">
                            <h3 class="text-center">Création de produits</h3>
                            <p class="text-center">Veuillez saisir les informations sur le produit</p>
                        </div>
                        <div>
                            <form>
                                <div class="form-group">
                                <label for="pname">Nom*</label>
                                <input type="text" class="form-control" id="pname" name="">
                                </div>
                                <div class="form-group">
                                <label for="pcat">Catégorie*</label>
                                <input type="text" class="form-control" id="pcat" name="">
                                </div>
                                <div class="form-group">
                                <label for="pmark">Marque*</label>
                                <input type="text" class="form-control" id="pmark" name="">
                                </div>
                                <div class="form-group">
                                <label for="pinit">Initiale*</label>
                                <input type="text" class="form-control" id="pinit" name="">
                                </div>
                                <div class="form-group">
                                <label for="punity">Unité*</label>
                                <input type="number" class="form-control" id="punity" name="">
                                </div>
                                <div class="form-group">
                                <label for="pprice">Prix*</label>
                                <input type="number" class="form-control" id="pprice" name="">
                                </div>
                                <div class="form-group">
                                <label for="pdesc">Description*</label>
                                <input type="text" class="form-control" id="pdesc" name="">
                                </div>
                                <button type="submit" class="btn btn-sm formbouton">Passer la commande</button>
                            </form>
                        </div>
                    </div>
                </div>
                <div class="col"></div>