                    <div class="entete">
                        <h3>Utilisateurs enregistrés</h3>
                    </div>
                    <div class="table-responsive tableau">
                        <table class="table text-center">
                            <thead>
                                <tr>
                                    <th>Nom</th>
                                    <th>Prénom</th>
                                    <th>Poste</th>
                                    <th>Magasin</th>
                                    <th colspan="2">Actions</th>
                                </tr>
                            </thead>
                            <tbody>
                                <tr>
                                    <td>RAKOTOZAFY</td>
                                    <td>Tina</td>
                                    <td>Caissier</td>
                                    <td>SANIFER Anosy</td>
                                    <td><a href="">Modifier</a></td>
                                    <td><a href="">Historique</a></td>
                                </tr>
                                <tr>
                                    <td>RAHARIJAONA</td>
                                    <td>Christian</td>
                                    <td>Responsable Magasinier</td>
                                    <td>SANIFER</td>
                                    <td><a href="">Modifier</a></td>
                                    <td><a href="">Historique</a></td>
                                </tr>
                                <tr>
                                    <td>RAKOTOMAHARISOA</td>
                                    <td>Rohiniaina</td>
                                    <td>Analamanga</td>
                                    <td>0341780028</td>
                                    <td><a href="">Modifier</a></td>
                                    <td><a href="">Historique</a></td>
                                </tr>
                                <tr>
                                    <td>ANDRIAMIZAKASON</td>
                                    <td>Toky</td>
                                    <td>Caissier</td>
                                    <td>Bricodis Behoririka</td>
                                    <td><a href="">Modifier</a></td>
                                    <td><a href="">Historique</a></td>
                                </tr>
                                <tr>
                                    <td>ANDRIAMIZAKASON</td>
                                    <td>Toky</td>
                                    <td>Caissier</td>
                                    <td>Bricodis Behoririka</td>
                                    <td><a href="">Modifier</a></td>
                                    <td><a href="">Historique</a></td>
                                </tr>
                                <tr>
                                    <td>ANDRIAMIZAKASON</td>
                                    <td>Toky</td>
                                    <td>Caissier</td>
                                    <td>Bricodis Behoririka</td>
                                    <td><a href="">Modifier</a></td>
                                    <td><a href="">Historique</a></td>
                                </tr>
                            </tbody>
                        </table>
                    </div>
                    <div>
                        <nav>
                            <ul class="pagination pagination-sm justify-content-center">
                                <li class="page-item disabled">
                                <a class="page-link">&laquo;</a>
                                </li>
                                <li class="page-item"><a class="page-link active" href="#">1</a></li>
                                <li class="page-item"><a class="page-link" href="#">2</a></li>
                                <li class="page-item"><a class="page-link" href="#">3</a></li>
                                <li class="page-item">
                                <a class="page-link" href="#">&raquo;</a>
                                </li>
                            </ul>
                        </nav>
                    </div>
                    <div class="d-grid gap-2 d-md-flex justify-content-md-end">
                        <a class="btn btn-sm btn-primary" type="button" href="administration-user-ajout.php">+ Ajouter un utilisateur</a>
                    </div>