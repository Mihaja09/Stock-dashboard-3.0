                    <div class="entete">
                        <h3>Fournisseurs de produits</h3>
                    </div>
                    <div class="table-responsive tableau">
                        <table class="table text-center">
                            <thead>
                                <tr>
                                    <th>Nom et Prénom</th>
                                    <th>Magasin</th>
                                    <th>Adresse</th>
                                    <th>Téléphone</th>
                                    <th colspan="2">Actions</th>
                                </tr>
                            </thead>
                            <tbody>
                                <tr>
                                    <td>RASOLOFO Joely</td>
                                    <td>Batimax</td>
                                    <td>Rue Docteur Joseph </td>
                                    <td>020 23 317 86</td>
                                    <td><a href="">Modifier</a></td>
                                    <td><a href="">Historique</a></td>
                                </tr>
                                <tr>
                                    <td>RAKOTOARISOA Mahefa</td>
                                    <td>Safina Import</td>
                                    <td>71, Rue De Liege</td>
                                    <td>+261 20 22 273 99</td>
                                    <td><a href="">Modifier</a></td>
                                    <td><a href="">Historique</a></td>
                                </tr>
                                <tr>
                                    <td>TOJO Falia</td>
                                    <td>Quincaillerie Firaisana</td>
                                    <td>Lalana Razafindranovona</td>
                                    <td>(+261) 20 22 224 16</td>
                                    <td><a href="">Modifier</a></td>
                                    <td><a href="">Historique</a></td>
                                </tr>
                                <tr>
                                    <td>Harena Lucka</td>
                                    <td>Magasin Rossane</td>
                                    <td>Lot IVI 14 Andravohangy </td>
                                    <td>034 20 917 43</td>
                                    <td><a href="">Modifier</a></td>
                                    <td><a href="">Historique</a></td>
                                </tr>
                                <tr>
                                    <td>Harena Lucka</td>
                                    <td>Magasin Rossane</td>
                                    <td>Lot IVI 14 Andravohangy </td>
                                    <td>034 20 917 43</td>
                                    <td><a href="">Modifier</a></td>
                                    <td><a href="">Historique</a></td>
                                </tr>
                                <tr>
                                    <td>Harena Lucka</td>
                                    <td>Magasin Rossane</td>
                                    <td>Lot IVI 14 Andravohangy </td>
                                    <td>034 20 917 43</td>
                                    <td><a href="">Modifier</a></td>
                                    <td><a href="">Historique</a></td>
                                </tr>
                            </tbody>
                        </table>
                    </div>
                    <div>
                        <nav>
                            <ul class="pagination pagination-sm justify-content-center">
                                <li class="page-item disabled">
                                <a class="page-link">&laquo;</a>
                                </li>
                                <li class="page-item"><a class="page-link active" href="#">1</a></li>
                                <li class="page-item"><a class="page-link" href="#">2</a></li>
                                <li class="page-item"><a class="page-link" href="#">3</a></li>
                                <li class="page-item">
                                <a class="page-link" href="#">&raquo;</a>
                                </li>
                            </ul>
                        </nav>
                    </div>
                    <div class="d-grid gap-2 d-md-flex justify-content-md-end">
                        <a class="btn btn-sm btn-primary" type="button" href="produits-fournisseurs-ajout.php">+ Ajouter un fournisseur</a>
                    </div>