                <div class="col"></div>
                <div class="centerform">    
                    
                    <div class="formul">
                        <div class="entete">
                            <h3 class="text-center">Fournisseur</h3>
                            <p class="text-center">Veuillez saisir les informations sur le fournisseur</p>
                        </div>
                        <div>
                            <form>
                                <div class="form-group">
                                <label for="pname">Nom et prénom*</label>
                                <input type="text" class="form-control" id="pname" name="">
                                </div>
                                <div class="form-group">
                                <label for="pshop">Magasin*</label>
                                <input type="text" class="form-control" id="pshop" name="">
                                </div>
                                <div class="form-group">
                                <label for="paddress">Adresse*</label>
                                <input type="text" class="form-control" id="paddress" name="">
                                </div>
                                <div class="form-group">
                                <label for="ptel">Numéro téléphone*</label>
                                <input type="tel" class="form-control" id="ptel" name="">
                                </div>
                                <button type="submit" class="btn btn-sm formbouton">Enregistrer</button>
                            </form>
                        </div>
                    </div>
                </div>
                <div class="col"></div>